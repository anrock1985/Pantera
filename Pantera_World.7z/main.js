var population = require('population');

module.exports.loop = function () {
    //console.log(population.miners.length);
    for (var i in Game.spawns) {
        population.checkPop(Game.spawns[i]);
    }
};